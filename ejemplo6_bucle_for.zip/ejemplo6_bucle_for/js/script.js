function cargarProvincias(){
    // Crear un array de provincias
    let arrayProvincias = ["Madrid", "Valencia", "Sevilla", "Toledo"];

    // Recorrer el array y por cada provincia generar una opcion
    for(let indice in arrayProvincias){
        document.getElementById("provincias").innerHTML +=
            "<option value='" + indice + "'>" +
                arrayProvincias[indice] + "</option>";
    }
}

function cargarPoblaciones(){
    var arrayPoblaciones = null;

    switch (document.getElementById("provincias").selectedIndex) {
        case 1:
            arrayPoblaciones = ["Getafe", "Las Rozas", "Torrelodones"];
            break;
    
        case 2:
            arrayPoblaciones = ["Gandia", "Oliva"];
            break;
        
        case 3:
            arrayPoblaciones = ["Dos Hermanas", "Espartinas", "Los Palacios"];
            break;
    
        case 4:
            arrayPoblaciones = ["Talavera", "Trillo"];
            break;
    }

    // Limpiar todas las opciones anteriores
    document.getElementById("poblaciones").innerHTML = 
        "<option>--Selecciona--</option>";

    // Por cada poblacion creamos una opcion
    for (let indice in arrayPoblaciones){
        let opt = new Option(arrayPoblaciones[indice], indice);
        document.getElementById("poblaciones").options[parseInt(indice)+1] = opt;
    }

}