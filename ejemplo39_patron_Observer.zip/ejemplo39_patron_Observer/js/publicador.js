class Publicador{

    subscriptores = new Array();

    constructor(){
        console.log("Se ha creado el publicador");
    }

    // Función para poder subscribirse
    subscribe(subscriptor){
        this.subscriptores.push(subscriptor);
    }

    // Función para borrar la subscripcion
    borrarse(subscriptor){
        this.subscriptores = this.subscriptores.filter((item) => 
            item !== subscriptor
        );
        console.log(`El subscriptor ${subscriptor.nombre} se ha dado de baja`);
    }

    emitir(noticia){
        // Se envia la noticia a todos los subscriptores
        this.subscriptores.forEach( (subscriptor) => {
            // Se la enviamos al buzon
            subscriptor.buzon(noticia);
        } );
    }
}