class Subscriptor{

    nombre;

    constructor(nombre){
        this.nombre = nombre;
        console.log(`Se ha creado a ${this.nombre} como subscriptor`);
    }

    buzon(noticia){
        console.log(`El subscriptor ${this.nombre} ha recibido ${noticia}`);
    }
}