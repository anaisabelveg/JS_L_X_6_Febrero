class Producto{

    // propiedades de instancia -> cada objeto mantiene una
    // copia de estas propiedades
    id;
    descripcion;
    precio;

    // propiedad de clase -> cuando solo existe una copia y
    // esta reside en la clase
    static #contador = 0;

    // constructor
    constructor(id, descripcion, precio){
        this.id = id;
        this.descripcion = descripcion;
        this.precio = precio;

        // Con los recursos estaticos no utilizamos el puntero this
        // Se utiliza:  NombreClase.recursoEstatico
        Producto.#contador++;
    }

    // Para acceder a un recurso estatico debe ser dentro de un
    // contexto estatico
    static getContador(){
        return Producto.#contador;
    }

    toString(){
        return "ID: " + this.id + ", Descripcion: " + this.descripcion +
            ", Precio: " + this.precio;
    }

    equals(otro){
        if(this.id === otro.id){
            return true;
        } else {
            return false;
        }
    }
}