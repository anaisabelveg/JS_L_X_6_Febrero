function mostrar(){

    // Resolucion de la pantalla
    console.log("Resolucion configurada: " + screen.width + "x" + screen.height);
    console.log("Resolucion real: " + window.innerWidth + "x" + window.innerHeight);

    // Navegador
    console.log("Navegador: " + navigator.appName);
    console.log("Navegador: " + navigator.appCodeName);
    console.log("Version: " + navigator.appVersion);
    console.log("Cookies habilitadas: " + navigator.cookieEnabled);
    console.log("Idioma: " + navigator.language);
    console.log("Idiomas: " + navigator.languages);

    // URL
    console.log("URL: " + location.pathname);
    console.log("Port: " + location.port);
    console.log("Host: " + location.host);
    console.log("HostName: " + location.hostname);
    console.log("Protocolo: " + location.protocol);
    console.log("Href: " + location.href);

    // Recargar la pagina
    //location.reload();

    // Reemplazar la URL
    //location.replace("http://www.google.es");

    // Acceder al historial
    console.log("Historial: " + history.length);
    //history.back();
    //history.forward();
}