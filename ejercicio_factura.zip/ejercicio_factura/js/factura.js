class Factura{

    // propiedades
    #numero;
    #cliente;
    #fecha;
    #productos;

    static #contador = 0;

    // constructor
    constructor(cliente, fecha, productos){
        this.#numero = ++Factura.#contador;
        this.#cliente = cliente;
        this.#fecha = fecha;
        this.#productos = productos;
    }

    getNumero(){
        return this.#numero;
    }

    getCliente(){
        return this.#cliente;
    }

    setCliente(cliente){
        this.#cliente = cliente;
    }

    getFecha(){
        return this.#fecha;
    }

    setFecha(fecha){
        this.#fecha = fecha;
    }

    getProductos(){
        return this.#productos;
    }

    setProductos(productos){
        this.#productos = productos;
    }

    toString(){
        return "Numero: " + this.#numero + ", Cliente: " + this.#cliente +
            ", Fecha: " + this.#fecha + ", Productos: " + this.#productos;
    }
}