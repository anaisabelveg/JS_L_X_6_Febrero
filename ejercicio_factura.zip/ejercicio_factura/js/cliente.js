class Cliente{

    // propiedades
    #nombre;
    #cif;
    #direccion;

    // constructor
    constructor(nombre, cif, direccion){
        this.#nombre = nombre;
        this.#cif = cif;
        this.#direccion = direccion;
    }

    getNombre(){
        return this.#nombre;
    }

    setNombre(nombre){
        this.#nombre = nombre;
    }

    getCif(){
        return this.#cif;
    }

    setCif(cif){
        this.#cif = cif;
    }

    getDireccion(){
        return this.#direccion;
    }

    setDireccion(direccion){
        this.#direccion = direccion;
    }

    toString(){
        return "Nombre: " + this.#nombre + ", CIF: " + this.#cif +
            ", Direccion: " + this.#direccion;
    }
}