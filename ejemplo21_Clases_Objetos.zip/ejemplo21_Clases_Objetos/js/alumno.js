class Alumno{

    // propiedades o atributos de la instancia
    nombre;
    apellido;
    curso;
    nota;

    // constructor por defecto
    // siempre va a existir
    // constructor(){}

    // constructor
    constructor(nombre, apellido, curso, nota){
        this.nombre = nombre;
        this.apellido = apellido;
        this.curso = curso;
        this.nota = nota;
    }

    // método o funciones o acciones
    mostrarInfo(){
        return "Nombre: " + this.nombre + 
               " Apellido: " + this.apellido +
               " Curso: " + this.curso + 
               " Nota: " + this.nota;
    }

}