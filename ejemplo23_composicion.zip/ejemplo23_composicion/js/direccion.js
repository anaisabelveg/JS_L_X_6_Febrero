class Direccion{

    #calle;
    #numero;
    #poblacion;

    /**
     * 
     * @param {String} calle 
     * @param {Number} numero 
     * @param {String} poblacion 
     */
    constructor(calle, numero, poblacion){
        this.setCalle(calle);
        this.setNumero(numero);
        this.setPoblacion(poblacion);
    }

    mostrar(){
        // Mayor, 5 - Madrid
        return this.#calle + ", " + this.#numero + " - " + this.#poblacion;
    }

    getCalle(){
        return this.#calle;
    }

    setCalle(calle){
        this.#calle = calle;
    }

    getNumero(){
        return this.#numero;
    }

    setNumero(numero){
        if (numero > 0){
            this.#numero = numero;
        }
    }

    getPoblacion(){
        return this.#poblacion;
    }

    setPoblacion(poblacion){
        this.#poblacion = poblacion;
    }
}