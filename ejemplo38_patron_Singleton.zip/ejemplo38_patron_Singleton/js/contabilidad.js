class Contabilidad{

    // unica instancia
    static unicaInstance;
    libro = Array();

    constructor(){
        // Si ya existe la instancia la devuelve sino la crea
        if (Contabilidad.unicaInstance){
            return Contabilidad.unicaInstance;
        } else {
            Contabilidad.unicaInstance = this;
        }
    }

    anotarAsiento(datos){
        console.log("Anotando en el libro de contabilidad " + datos);
        this.libro.push(datos);
    }

}