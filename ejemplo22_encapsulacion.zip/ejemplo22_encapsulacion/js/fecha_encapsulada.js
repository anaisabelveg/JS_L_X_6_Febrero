// Una clase encapsulada es aquella que tiene todas sus propiedades
// declaradas como privadas y solo se accede a ellas a través
// de los métodos get y set publicos

class FechaEncapsulada{

    // Atributos o propiedades PRIVADOS
    #dia;
    #mes;
    #anyo;

    constructor(dia, mes, anyo){
        this.setDia(dia);
        this.setMes(mes);
        this.setAnyo(anyo);
    }

    getDia(){
        return this.#dia;
    }

    setDia(dia){
        if (dia >= 1 && dia <= 30){
            this.#dia = dia;
        } else {
            console.log("Dia no valido");
        }
    }

    getMes(){
        return this.#mes;
    }

    setMes(mes){
        if (mes >= 1 && mes <= 12){
            this.#mes = mes;
        } else {
            console.log("Mes no valido");
        }
    }

    getAnyo(){
        return this.#anyo;
    }

    setAnyo(anyo){
        if (anyo == 2023 || anyo == 2024){
            this.#anyo = anyo;
        } else {
            console.log("Año no valido");
        }
    }

    mostrar(){
        return this.#dia + "/" + this.#mes + "/" + this.#anyo;
    }
}