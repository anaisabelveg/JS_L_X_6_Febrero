// Importar solo 2 funciones: longitud y buscar
import {longitud, buscar} from './textos.js';

console.log("Longitud: " + longitud("Esto es una prueba"));
console.log("Buscar: " + buscar("Esto es una prueba", "p"));