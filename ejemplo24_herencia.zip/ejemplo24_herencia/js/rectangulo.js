class Rectangulo extends Figura{

    // propiedades
    base;
    altura;

    constructor(x, y, base, altura){
        super(x, y); // Llamamos al constructor de la superclase
        this.base = base;
        this.altura = altura;
    }

    // Sobreescribimos el metodo area
    area(){
        return this.base * this.altura;
    }

    // Invocar al método sobreescrito
    mostrarDatos(){
        return super.mostrarDatos() +  
            " Base: " + this.base + " Altura: " + this.altura;
    }
}