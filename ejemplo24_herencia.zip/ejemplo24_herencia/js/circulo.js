class Circulo extends Figura{

    // propiedad
    radio;

    constructor(x, y, radio){
        super(x, y); // Llamar al constructor de la superclase
        this.radio = radio;
    }

    // Sobreescribir el método area
    area(){
        return Math.PI * Math.pow(this.radio, 2);
    }

    // Invocar al metodo sobreescrito
    mostrarDatos(){
        return super.mostrarDatos() + " Radio: " + this.radio;
    }
}