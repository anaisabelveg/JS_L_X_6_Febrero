class Strategy{

    algoritmo(){       
    }

}