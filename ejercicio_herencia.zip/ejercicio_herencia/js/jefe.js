class Jefe extends Empleado{

    // Propiedades
    #bonus;

    // Constructor
    constructor(nombre, edad, sueldo, bonus){
        super(nombre, edad, sueldo);
        this.setBonus(bonus);
    }

    getBonus(){
        return this.#bonus;
    }

    setBonus(bonus){
        if (bonus > 0){
            this.#bonus = bonus;
        }
    }

    mostrarInfo(){
        return super.mostrarInfo() + " Bonus: " + this.#bonus;
    }
}