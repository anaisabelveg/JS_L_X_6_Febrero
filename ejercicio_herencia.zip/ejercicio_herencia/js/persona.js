class Persona{

    // Propiedades privadas
    #nombre;
    #edad;

    // Constructor
    constructor(nombre, edad){
        this.setNombre(nombre);
        this.setEdad(edad);
    }

    getNombre(){
        return this.#nombre;
    }

    setNombre(nombre){
        this.#nombre = nombre;
    }

    getEdad(){
        return this.#edad;
    }

    setEdad(edad){
        if (edad > 0){
            this.#edad = edad;
        }
    }

    mostrarInfo(){
        return "Nombre: " + this.#nombre + " Edad: " + this.#edad;
    }

}