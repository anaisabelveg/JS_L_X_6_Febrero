class Empleado extends Persona{

    // Propiedades
    #sueldo;

    // Constructor
    constructor(nombre, edad, sueldo){
        super(nombre, edad);
        this.setSueldo(sueldo);
    }

    getSueldo(){
        return this.#sueldo;
    }

    setSueldo(sueldo){
        if (sueldo > 800){
            this.#sueldo = sueldo;
        }
    }

    mostrarInfo(){
        return super.mostrarInfo() + " Sueldo: " + this.#sueldo;
    }
}