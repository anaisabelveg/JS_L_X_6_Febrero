function mostrar(event){
    
    // Cancelar el evento submit
    event.preventDefault();

    console.log("Nombre: " + formulario.nombre.value );
    console.log("PW: " + formulario.pw.value );
    console.log("Apellido: " + formulario.apellido.value );
    console.log("Edad: " + formulario.edad.value );
    console.log("Email: " + formulario.email.value );
    console.log("Sito Web: " + formulario.web.value );
    console.log("Telefono: " + formulario.telefono.value );
    console.log("Fecha Nacimiento: " + formulario.nacimiento.value );
    console.log("Sexo: " + formulario.sexo.value );
    console.log("Estudios: " + formulario.estudios.value );

    for(let i in document.getElementById("cursos").options){
        if (document.getElementById("cursos").options[i].selected){
            console.log("Cursos: " + 
                document.getElementById("cursos").options[i].text)
        }
    }
}